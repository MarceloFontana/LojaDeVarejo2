class LojaDeVarejo{

}