class Produto {
    var estoque:String
    var nomeDoProduto:String
    var preco:String
    var validade:String

    constructor(
        estoque:String,
        nomeDoProduto:String,
        preco:String,
        validade:String
    ){
        this.estoque = estoque
        this.nomeDoProduto = nomeDoProduto
        this.preco = preco
        this.validade = validade
    }
}